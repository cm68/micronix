cd /usr/src/cmd/whitesmith/include
make $1

/* Characters will be unsigned if included before header files */
#define UTEXT

/*	HEADER FOR MATH FUNCTION DEFINITIONS
 *	Copyright (c) 1983 by Whitesmiths, Ltd.
 */

DOUBLE atan();
DOUBLE atof();
DOUBLE cos();
DOUBLE exp();
DOUBLE log();
DOUBLE log10();
DOUBLE pow();
DOUBLE sin();
DOUBLE sqrt();
DOUBLE tan();

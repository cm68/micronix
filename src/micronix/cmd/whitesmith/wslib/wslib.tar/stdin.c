/*	FIO STRUCTURE FOR STDIN
 *	copyright (c) 1978 by Whitesmiths, Ltd.
 */
#include <std.h>

GLOBAL FIO stdin {STDIN, 0, READ, 0};

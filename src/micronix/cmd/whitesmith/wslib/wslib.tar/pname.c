/*	DEFAULT PROGRAM NAME
 *	copyright (c) 1981 by Whitesmiths, Ltd.
 */
#include <std.h>

TEXT *_pname {"error"};

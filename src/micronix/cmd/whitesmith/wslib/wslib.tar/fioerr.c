/*	NULL FIO POINTER CONDITION
 *	copyright (c) 1982 by Whitesmiths, Ltd.
 */
#include <std.h>

TEXT *fioerr {"NULL FIO pointer"};

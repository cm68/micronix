/*	FIO STRUCTURE FOR STDOUT
 *	copyright (c) 1978 by Whitesmiths, Ltd.
 */
#include <std.h>

GLOBAL FIO stdout {STDOUT, 0, WRITE, 0};

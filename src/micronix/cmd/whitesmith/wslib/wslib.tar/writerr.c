/*	WRITE ERROR CONDITION
 *	copyright (c) 1982 by Whitesmiths, Ltd.
 */
#include <std.h>

TEXT *writerr {"write error"};
